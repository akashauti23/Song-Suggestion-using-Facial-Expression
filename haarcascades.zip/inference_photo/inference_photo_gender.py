from config import *
#from Dataloader import *
from model import *
#from train import *


model_gender = load_model(weights)
model_gender.load_weights(weights)

images = []
for filename in os.listdir(inferenceDir):
    if filename.endswith(".jpg") or filename.endswith(".png"):
        image_path = os.path.join(inferenceDir, filename)
        image = Image.open(image_path)
        # preprocess the image
        image = image.resize((224, 224)) # example resizing to 224x224
        image = np.array(image)
        images.append(image)
images = np.array(images)


# Make predictions on the images using the model
A=model_gender.predict(images)


FER=[]
for i in range(1):
    predicted_class = np.argmax(A[i])
    fer= ['Female', 'Male']
    z=fer[predicted_class]
    FER.append(z)
    
#print(FER)

# Display the predicted age and gender for each image
for i in range(len(images)):
    plt.imshow(images[i])
    plt.title(f"Predicted Emotion: {FER[i]} ")
    plt.show()
    
    
